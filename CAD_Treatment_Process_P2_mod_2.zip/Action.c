﻿Action()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=76", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(6);

	web_url("SmileDirectClubWeb", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=custom/style.css", ENDITEM, 
		"Url=receiver/images/1x/CitrixReceiver_WebScreen_CBE548FB8FEE049E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=https://ssl.gstatic.com/safebrowsing/csd/client_model_v5_variation_0.pb", "Referer=", ENDITEM, 
		"Url=receiver/js/external/hammer.v2.0.8.min_F699A1E56189259A.js", ENDITEM, 
		"Url=https://ssl.gstatic.com/safebrowsing/csd/client_model_v5_ext_variation_0.pb", "Referer=", ENDITEM, 
		"Url=receiver/js/external/velocity.min_B218502A82F66680.js", ENDITEM, 
		"Url=receiver/js/external/jquery.dotdotdot.min_08EE54CBA886AD0A.js", ENDITEM, 
		"Url=receiver/images/1x/actionSprite_531B7A6FF85CA98E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/js/ctxs.webui.min_895B3076E3BA6027.js", ENDITEM, 
		"Url=receiver/js/external/slick.min_FEB62CC230E2BA2A.js", ENDITEM, 
		"Url=receiver/images/common/ReceiverFullScreenBackground_46E559C0E6B5A27B.jpg", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/images/1x/folder_template_C13BB96DEBC9F30F.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/js/ctxs.core.min_33B1CC992A07D57E.js", ENDITEM, 
		"Url=custom/script.js", ENDITEM, 
		"Url=custom/strings.en.js", ENDITEM, 
		"Url=receiver/images/1x/viewSprite_B2F322BDCB824FAF.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/images/common/authspinner_B0BCD339560CA593.gif", ENDITEM, 
		"Url=receiver/images/common/icon_loading_9A0623127A028FEB.png", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2NqTTJXVmxLZW1OTFNISnJWREJMZG5GbGRWbGxTVGNyTVRFMFBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2JHRnhlRmhYYmtwdmJqbFVWV3hwVlZaV1EyOXBlbmxITTI5QlBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL1duZHhaRlZXV0VWTWRuYzNPRGw2VEhWUUsyRkNTSE5WYVhoclBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2NFTm9NM1JKUnpObVZFTnpORXhRTUUxT2EyY3lVa3N5TXl0alBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL1UxZFNOblpTYkhaRmVUbEJNRzAzTjB3MWNHRkRLMUIyYm1zNFBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL00zZE9NVWROUmtWMFQwZDBhME5yWVRJM2NsaDBia04yUTFkU1QxbFNkVGhXU1ZWQlRXWlNWbFJpZHowLS9pbWFnZQ--?size=128", ENDITEM, 
		LAST);

	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

/*Correlation comment: Automatic rules - Do not change!  
Original value='0A23C0CF9390A87C85A78E1AEEF37762' 
Name ='CitrixXenApp_CsrfToken' 
Type ='Rule' 
AppName ='Citrix_XenApp' 
RuleName ='CsrfToken'*/
	web_reg_save_param_ex(
		"ParamName=CitrixXenApp_CsrfToken",
		"LB/IC=CsrfToken=",
		"RB/IC=;",
		SEARCH_FILTERS,
		"Scope=Cookies",
		LAST);

	web_custom_request("Configuration", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Home/Configuration", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=", 
		EXTRARES, 
		"Url=https://clients1.google.com/tbproxy/af/query?q=Chc2LjEuMTcxNS4xNDQyL2VuIChHR0xMKRMZtxZWN-1XI8ojLXBB36gkIy0pLWCOJBQ=", "Referer=", ENDITEM, 
		LAST);

	web_add_auto_header("Csrf-Token",
		"{CitrixXenApp_CsrfToken}");

	web_custom_request("GetDetectionTicket", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionTicket", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_submit_data("GetDetectionStatus", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionStatus", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=ticket", "Value=CDT_sPLCRMZ4kGFfO8EBGcKUVLikRJz1Uo6OkJgmxJQPK0CEUdmmVW8MQh5WtjsSDC9s", ENDITEM, 
		LAST);

	web_submit_data("GetDetectionStatus_2", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionStatus", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=ticket", "Value=CDT_sPLCRMZ4kGFfO8EBGcKUVLikRJz1Uo6OkJgmxJQPK0CEUdmmVW8MQh5WtjsSDC9s", ENDITEM, 
		LAST);

	web_add_cookie("CtxsUserPreferredClient=Native; DOMAIN=storefront.smileco.com");

	web_add_cookie("CtxsClientDetectionDone=true; DOMAIN=storefront.smileco.com");

	web_add_cookie("CtxsHasUpgradeBeenShown=true; DOMAIN=storefront.smileco.com");

	web_submit_data("List", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/List", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=format", "Value=json", ENDITEM, 
		"Name=resourceDetails", "Value=Default", ENDITEM, 
		LAST);

	web_custom_request("GetAuthMethods", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/GetAuthMethods", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("Login", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/Login", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/vnd.citrix.authenticateresponse-1+xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"EncType=", 
		EXTRARES, 
		"Url=../receiver/images/1x/CitrixStoreFront_auth_14B96BFF2B0A6FF8.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=https://clients1.google.com/tbproxy/af/query?q=Chc2LjEuMTcxNS4xNDQyL2VuIChHR0xMKRMZvqVRrhN9bbIjLeeNQA4kIy3OQUx6JBQ=", "Referer=", ENDITEM, 
		LAST);

	web_revert_auto_header("Csrf-Token");

	web_revert_auto_header("X-Citrix-IsUsingHTTPS");

	web_revert_auto_header("X-Requested-With");

	web_submit_data("reportDetectionStatus", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClub/clientAssistant/reportDetectionStatus", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=ticket", "Value=CDT_sPLCRMZ4kGFfO8EBGcKUVLikRJz1Uo6OkJgmxJQPK0CEUdmmVW8MQh5WtjsSDC9s", ENDITEM, 
		"Name=protocolVersion", "Value=1", ENDITEM, 
		"Name=hdxVersion", "Value=14.7.0.13011", ENDITEM, 
		"Name=hdxIsPassthrough", "Value=False", ENDITEM, 
		"Name=hdxIsPassthroughVariable", "Value=False", ENDITEM, 
		EXTRARES, 
		"Url=/Citrix/SmileDirectClubWeb/receiver/images/1x/spinner_white_auth_button_53FD5A337A529DA7.gif", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		LAST);

	lr_start_transaction("Login");

	web_add_auto_header("Csrf-Token",
		"{CitrixXenApp_CsrfToken}");

	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_data("LoginAttempt", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/LoginAttempt", 
		"Method=POST", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=username", "Value=Crtest.user5", ENDITEM, 
		"Name=password", "Value=P@$$word5", ENDITEM, 
		"Name=saveCredentials", "Value=false", ENDITEM, 
		"Name=loginBtn", "Value=Log On", ENDITEM, 
		"Name=StateContext", "Value=", ENDITEM, 
		LAST);

	web_add_cookie("CtxsPasswordChangeAllowed=true; DOMAIN=storefront.smileco.com");

	web_submit_data("List_2", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/List", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=format", "Value=json", ENDITEM, 
		"Name=resourceDetails", "Value=Default", ENDITEM, 
		EXTRARES, 
		"Url=../receiver/images/1x/CitrixReceiverLogo_Home_5C24BCEC5A182425.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/spinner_5CF0D1C8A76AAC8E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/ico_search_E84E3D63D821F80D.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/search_close_BC5A22358E58905F.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		LAST);

	web_custom_request("GetUserName", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/GetUserName", 
		"Method=POST", 
		"Resource=0", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("AllowSelfServiceAccountManagement", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/AllowSelfServiceAccountManagement", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	lr_end_transaction("Login",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("Click_VDI");

	web_submit_data("WGVuRGVza3RvcCBDb250cm9sbGVyLkNBRFBlcmZvcm1hbmNlICRTODEtMTQ0", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/GetLaunchStatus/WGVuRGVza3RvcCBDb250cm9sbGVyLkNBRFBlcmZvcm1hbmNlICRTODEtMTQ0", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=displayNameDesktopTitle", "Value=CADPerformance", ENDITEM, 
		"Name=createFileFetchTicket", "Value=false", ENDITEM, 
		EXTRARES, 
		"Url=https://safebrowsing.googleapis.com/v4/threatListUpdates:fetch?$req="
		"Ch0KDGdvb2dsZWNocm9tZRINNzYuMC4zODA5LjEzMhopCAUQARobCg0IBRAGGAEiAzAwMTABENqXBxoCGAXODvjkIgQgASACKAEaKQgBEAEaGwoNCAEQBhgBIgMwMDEwARCBuwYaAhgFxOjqsCIEIAEgAigBGikIBxABGhsKDQgHEAYYASIDMDAxMAEQ6oIGGgIYBfn9hEsiBCABIAIoARonCAEQARoZCg0IARAGGAEiAzAwMTADEBQaAhgFWvtz7SIEIAEgAigDGigIARAIGhoKDQgBEAgYASIDMDAxMAQQnhgaAhgF2vACNiIEIAEgAigEGicICRABGhkKDQgJEAYYASIDMDAxMAYQAhoCGAUpMKEkIgQgASACKAYaKAgPEAEaGgoNCA8QBhgBIgMwMDEwARDKBBoCGAWq0vhuIgQgASACKAEaJwgJEAEaGQoNCAkQBhgBIgMwMDEwARAVGgIYBddYphwiBCABIAIoARonCAoQCBoZCg"
		"0IChAIGAEiAzAwMTABEAUaAhgFYb4sSiIEIAEgAigBGigICBABGhoKDQgIEAYYASIDMDAxMAEQ5AYaAhgFrzfqvSIEIAEgAigBGigIDRABGhoKDQgNEAYYASIDMDAxMAEQ5EoaAhgFZMfPBCIEIAEgAigBGikIAxABGhsKDQgDEAYYASIDMDAxMAEQrrwGGgIYBb3K6uAiBCABIAIoARopCA4QARobCg0IDhAGGAEiAzAwMTABEO-gAhoCGAVuWzWWIgQgASACKAEiAggB&$ct=application/x-protobuf&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", "Referer=", ENDITEM, 
		LAST);

	ctrx_nfuse_connect("https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/LaunchIca/WGVuRGVza3RvcCBDb250cm9sbGVyLkNBRFBlcmZvcm1hbmNlICRTODEtMTQ0.ica?CsrfToken={CitrixXenApp_CsrfToken}&IsUsingHttps=Yes&displayNameDesktopTitle=CADPerformance&launchId=1568803948756", CTRX_LAST);

	lr_end_transaction("Click_VDI",LR_AUTO);

	lr_start_transaction("Open_VDI");

	ctrx_wait_for_event("LOGON", CTRX_LAST);

	lr_end_transaction("Open_VDI",LR_AUTO);

	lr_start_transaction("Open_CAD");

	ctrx_mouse_click(38, 227, LEFT_BUTTON, 0, "NULL", CTRX_LAST);

	ctrx_sync_on_window("Desktop", ACTIVATE, 0, 0, 1281, 1025, "", CTRX_LAST);

	ctrx_mouse_double_click(38, 227, LEFT_BUTTON, 0, "Desktop", CTRX_LAST);

	ctrx_mouse_up(38, 227, LEFT_BUTTON, 0, "Desktop", CTRX_LAST);

	ctrx_mouse_click(52, 227, LEFT_BUTTON, 0, "Desktop", CTRX_LAST);

	ctrx_key("ENTER_KEY", 0, "", CTRX_LAST);

	lr_end_transaction("Open_CAD",LR_AUTO);

	lr_think_time(14);

	lr_start_transaction("Patient_files");

	ctrx_sync_on_window("CA Digital - CA Digital", ACTIVATE, 0, 0, 1281, 985, "", CTRX_LAST);

	ctrx_mouse_click(337, 657, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	lr_end_transaction("Patient_files",LR_AUTO);

	lr_think_time(9);

	lr_start_transaction("Crate");

	ctrx_mouse_click(887, 762, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	lr_end_transaction("Crate",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("Patient_details");

	ctrx_mouse_click(1117, 263, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_type("CADP", "", CTRX_LAST);

	ctrx_type("12356456", "", CTRX_LAST);

	ctrx_mouse_click(1125, 302, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_type("CADF12356456", "", CTRX_LAST);

	ctrx_mouse_click(1133, 342, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_type("CADL12356456", "", CTRX_LAST);

	ctrx_mouse_click(1130, 387, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_type("01/07/1986", "", CTRX_LAST);

	ctrx_mouse_click(1123, 422, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_type("MRN12356456", "", CTRX_LAST);

	ctrx_mouse_click(1127, 506, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_type("09/18/2019", "", CTRX_LAST);

	ctrx_mouse_click(1192, 907, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	lr_end_transaction("Patient_details",LR_AUTO);

	lr_think_time(15);

	lr_start_transaction("Import_stl_files");

	ctrx_mouse_click(247, 57, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	lr_think_time(11);

	ctrx_sync_on_window("Load document...", ACTIVATE, 415, 309, 450, 364, "", CTRX_LAST);

	ctrx_mouse_click(429, 212, LEFT_BUTTON, 0, "Load document...", CTRX_LAST);

	ctrx_sync_on_window("Open", ACTIVATE, 220, 272, 841, 433, "", CTRX_LAST);

	ctrx_mouse_click(46, 320, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_double_click(155, 207, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	lr_think_time(5);

	ctrx_mouse_click(818, 346, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(818, 346, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(818, 346, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	web_revert_auto_header("Csrf-Token");

	web_revert_auto_header("X-Citrix-IsUsingHTTPS");

	web_revert_auto_header("X-Requested-With");

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=9:656415940&cup2hreq=8cb45fcd51f4f0e9653f3a76930e56a030bc4ed2575357b754df4df75d06c67f", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx2,crx3\",\"app\":[{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"GCEB\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{0c154c99-a80b-455b-9c3b-e3a9276465b8}\",\"rd\":4643},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"GCEB\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{0e5cf2dc-3a35-43b9-8efe-d2bf6f854c06}\",\"rd\":4643},\"updatecheck\":{},\""
		"version\":\"4.10.1440.18\"},{\"appid\":\"mimojjlkmoijpicakmndhoigimigcmbb\",\"brand\":\"GCEB\",\"cohort\":\"1:d0j:\",\"cohorthint\":\"Chrome [M50... M99]\",\"cohortname\":\"Chrome [M50... M99]\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.92d2e1183317fff87c7bcdccfbb5da46bfa0ab42cf17ba18d37424c8b084e5e5\"}]},\"ping\":{\"ping_freshness\":\"{ba9c00a3-1245-4502-9367-a0adecf6eddc}\",\"rd\":4643},\"updatecheck\":{},\"version\":\"32.0.0.255\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\","
		"\"brand\":\"GCEB\",\"cohort\":\"1:bm1:sbl@0.01,sf3@0.1\",\"cohorthint\":\"M54ToM99\",\"cohortname\":\"M54ToM99\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.72ae053d74e3a8df90460d740b8e33a80ba24509b65fddb66f53609aecdbbcf7\"}]},\"ping\":{\"ping_freshness\":\"{149cab84-b16b-45fa-8dc3-e832cbabeb68}\",\"rd\":4643},\"updatecheck\":{},\"version\":\"9.4.1\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"GCEB\",\"enabled\":true,\"ping\":{\"ping_freshness\":\""
		"{21d95759-770d-4941-80f9-c0e942d18bcf}\",\"rd\":4643},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"hnimpnehoodheedghdeeijklkeaacbdc\",\"brand\":\"GCEB\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.6f6bc93dcd62dc251850d2ff458fda96083ceb7fbe8eeb11248b8485ef2aea23\"}]},\"ping\":{\"ping_freshness\":\"{4447b554-0c5b-4e70-9763-153193073d1d}\",\"rd\":4643},\"updatecheck\":{},\"version\":\"0.57.44.2492\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"GCEB\",\"cohort\""
		":\"1:jcl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.5f816d2412719219662a5946aa90f6d112149bd84aa6f720ef685224e5b65d4d\"}]},\"ping\":{\"ping_freshness\":\"{08d6add8-6c6e-4df9-9f9b-d53f67610fcc}\",\"rd\":4643},\"updatecheck\":{},\"version\":\"5404\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"GCEB\",\"cohort\":\"1:cux:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":"
		"\"1.fd49e95c952bdb265a80513767311a5e069ac9dbf2ed4b480b96513b0ccbe086\"}]},\"ping\":{\"ping_freshness\":\"{6148fc44-5e60-4ae6-b8c0-bbd536af40e8}\",\"rd\":4643},\"updatecheck\":{},\"version\":\"36\"},{\"appid\":\"aemomkdncapdnfajjbbcbdebjljbpmpj\",\"brand\":\"GCEB\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{e123b94a-bd72-4c38-8238-24f232f7553a}\",\"rd\":4643},\"updatecheck\":{},\"version\":\"1.0.5.0\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"GCEB\",\"cohort\":\"1:j5l:\",\""
		"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.3eb16d6c28b502ac4cfee8f4a148df05f4d93229fa36a71db8b08d06329ff18a\"}]},\"ping\":{\"ping_freshness\":\"{3dfe80f2-5b48-4f06-96a2-cfb2599d29ef}\",\"rd\":4643},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"gkmgaooipdjhmangpemjhigmamcehddo\",\"brand\":\"GCEB\",\"cohort\":\"1:pw3:\",\"cohorthint\":\"Stable\",\"cohortname\":\"Stable\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.7a3dc46bd077761c1b8f722d10a0cd89ba6a2d378d0695ac035a8f21b2f4e5e6\"}]},\"ping\":{\"ping_freshness\":\"{3a4eb3c5-222e-48ee-b507-f42cb60215bf}\",\"rd\":4643},\"tag\":\"eset_exp_b\",\"updatecheck\":{},\"version\":\"44.218.200\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"GCEB\",\"cohort\":\"1:ofl:\",\"cohorthint\":\"stable64\",\"cohortname\":\"stable64\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\""
		"ping\":{\"ping_freshness\":\"{c638dbf0-aee9-46e9-a231-7f60a63cde08}\",\"rd\":4643},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\"copjbmjbojbakpaedmpkhmiplmmehfck\",\"brand\":\"GCEB\",\"cohort\":\"1:p1x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.207921137eee9c0831e0bd890330986c10dfd9382034491b82de3f86ae6915f7\"}]},\"ping\":{\"ping_freshness\":\"{0bcf1292-7c76-4565-9b4d-b1a95f9392af}\",\"rd\":4643},\"updatecheck\":{},\""
		"version\":\"2018.9.6.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":true,\"hw\":{\"physmemory\":32},\"lang\":\"en-US\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.14393.3204\"},\"prodversion\":\"76.0.3809.132\",\"protocol\":\"3.1\",\"requestid\":\"{4189a97a-aaa2-4ae3-b3fc-2f1d4e06e879}\",\"sessionid\":\"{80bd840c-be02-4eb2-95f3-1d71745114bf}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\""
		"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.34.11\"},\"updaterversion\":\"76.0.3809.132\"}}", 
		LAST);

	ctrx_type("v", "", CTRX_LAST);

	ctrx_mouse_click(452, 97, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(761, 375, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(182, 134, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(771, 372, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	lr_think_time(9);

	ctrx_mouse_click(197, 100, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(762, 377, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	lr_think_time(5);

	ctrx_mouse_click(410, 77, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(763, 372, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_sync_on_window("Load document...", ACTIVATE, 415, 309, 450, 364, "", CTRX_LAST);

	ctrx_mouse_click(431, 253, LEFT_BUTTON, 0, "Load document...", CTRX_LAST);

	ctrx_sync_on_window("Open", ACTIVATE, 220, 272, 841, 433, "", CTRX_LAST);

	ctrx_mouse_click(363, 100, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(764, 376, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_sync_on_window("Load document...", ACTIVATE, 415, 309, 450, 364, "", CTRX_LAST);

	ctrx_mouse_click(228, 333, LEFT_BUTTON, 0, "Load document...", CTRX_LAST);

	lr_end_transaction("Import_stl_files",LR_AUTO);

	lr_think_time(44);

	lr_start_transaction("Open_Impressions");

	ctrx_sync_on_window("CA Digital - CA Digital", ACTIVATE, 0, 0, 1281, 985, "", CTRX_LAST);

	ctrx_mouse_double_click(275, 298, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	lr_think_time(21);

	ctrx_mouse_double_click(273, 294, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_mouse_up(273, 294, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	lr_end_transaction("Open_Impressions",LR_AUTO);

	lr_think_time(32);

	lr_start_transaction("Step1");

	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, 0, 0, 1281, 985, "", CTRX_LAST);

	ctrx_mouse_click(648, 179, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_end_transaction("Step1",LR_AUTO);

	lr_think_time(38);

	lr_start_transaction("Step2");

	ctrx_mouse_click(119, 134, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(21);

	ctrx_mouse_click(794, 523, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(949, 521, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(953, 522, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(795, 628, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(948, 630, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(9);

	ctrx_mouse_click(161, 465, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(176, 414, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(182, 365, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(196, 330, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(215, 298, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(242, 277, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(273, 263, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(320, 256, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(344, 273, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(379, 297, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(395, 327, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(411, 363, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(10);

	ctrx_mouse_click(420, 405, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(437, 456, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(9);

	ctrx_mouse_click(173, 701, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(186, 754, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(199, 797, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(208, 831, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(225, 863, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(252, 875, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(279, 882, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(306, 884, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(334, 877, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(359, 868, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(380, 836, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(394, 804, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(9);

	ctrx_mouse_click(407, 759, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(421, 707, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(5);

	ctrx_mouse_click(810, 577, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_end_transaction("Step2",LR_AUTO);

	lr_think_time(115);

	lr_start_transaction("step3");

	ctrx_mouse_click(184, 133, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(125);

	ctrx_mouse_click(62, 295, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(770, 187, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(761, 235, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(10);

	ctrx_mouse_click(193, 755, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(190, 757, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(16);

	ctrx_mouse_click(427, 403, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_double_click(427, 406, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_up(427, 406, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(50);

	ctrx_mouse_click(322, 255, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(350, 231, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(39);

	ctrx_mouse_click(331, 235, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(18);

	ctrx_mouse_down(348, 244, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_up(347, 247, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(4);

	ctrx_mouse_click(354, 243, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(4);

	ctrx_mouse_click(352, 243, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(352, 243, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(9);

	ctrx_mouse_down(362, 261, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(4);

	ctrx_mouse_up(352, 273, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(6);

	ctrx_mouse_down(325, 257, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_up(325, 260, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_end_transaction("step3",LR_AUTO);

	lr_think_time(22);

	lr_start_transaction("step4");

	ctrx_mouse_click(250, 125, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_end_transaction("step4",LR_AUTO);

	lr_think_time(44);

	lr_start_transaction("Export_stl_files");

	ctrx_mouse_click(58, 918, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(7);

	ctrx_sync_on_window("Save", ACTIVATE, 200, 273, 882, 433, "", CTRX_LAST);

	ctrx_mouse_click(866, 209, LEFT_BUTTON, 0, "Save", CTRX_LAST);

	ctrx_sync_on_window("Select Export File Types", ACTIVATE, 508, 391, 265, 201, "", CTRX_LAST);

	ctrx_mouse_click(22, 48, LEFT_BUTTON, 0, "Select Export File Types", CTRX_LAST);

	ctrx_mouse_click(25, 79, LEFT_BUTTON, 0, "Select Export File Types", CTRX_LAST);

	lr_think_time(6);

	ctrx_mouse_click(64, 169, LEFT_BUTTON, 0, "Select Export File Types", CTRX_LAST);

	web_add_cookie("CtxsDesktopAutoLaunchDone=no; DOMAIN=storefront.smileco.com");

	web_add_header("Csrf-Token",
		"{CitrixXenApp_CsrfToken}");

	web_add_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_custom_request("Logoff", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/Logoff", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	lr_think_time(6);

	ctrx_sync_on_window("Save", ACTIVATE, 200, 273, 882, 433, "", CTRX_LAST);

	ctrx_mouse_click(805, 371, LEFT_BUTTON, 0, "Save", CTRX_LAST);

	lr_end_transaction("Export_stl_files",LR_AUTO);

	lr_think_time(123);

	lr_start_transaction("Home");

	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, 0, 0, 1281, 985, "", CTRX_LAST);

	ctrx_mouse_click(162, 62, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_end_transaction("Home",LR_AUTO);

	lr_think_time(20);

	lr_start_transaction("Close_CAD");

	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, 0, 0, 1281, 985, "", CTRX_LAST);

	ctrx_mouse_click(1250, 14, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(1251, 11, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_end_transaction("Close_CAD",LR_AUTO);

	lr_start_transaction("Close_citrix");

	ctrx_logoff(CTRX_NORMAL_LOGOFF, CTRX_LAST);

	lr_end_transaction("Close_citrix",LR_AUTO);
	
	
	lr_start_transaction("Logout");

	web_add_cookie("CtxsDesktopAutoLaunchDone=no; DOMAIN=storefront.smileco.com");

	lr_think_time(13);

	web_custom_request("Disconnect", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Sessions/Disconnect", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("Logoff", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/Logoff", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);
	
	lr_end_transaction("Logout", LR_AUTO);

	

	return 0;
}