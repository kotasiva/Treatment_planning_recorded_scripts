Action()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=76", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t1.inf", 
		LAST);

	lr_think_time(6);

	web_url("client_model_v5_variation_0.pb", 
		"URL=https://ssl.gstatic.com/safebrowsing/csd/client_model_v5_variation_0.pb", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t2.inf", 
		LAST);

	web_url("client_model_v5_ext_variation_0.pb", 
		"URL=https://ssl.gstatic.com/safebrowsing/csd/client_model_v5_ext_variation_0.pb", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t3.inf", 
		LAST);

	lr_think_time(54);

	web_url("SmileDirectClubWeb", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=custom/style.css", ENDITEM, 
		"Url=receiver/js/external/hammer.v2.0.8.min_F699A1E56189259A.js", ENDITEM, 
		"Url=receiver/js/external/jquery.dotdotdot.min_08EE54CBA886AD0A.js", ENDITEM, 
		"Url=receiver/js/external/velocity.min_B218502A82F66680.js", ENDITEM, 
		"Url=receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/js/external/slick.min_FEB62CC230E2BA2A.js", ENDITEM, 
		"Url=receiver/js/ctxs.core.min_33B1CC992A07D57E.js", ENDITEM, 
		"Url=receiver/images/1x/actionSprite_531B7A6FF85CA98E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/js/ctxs.webui.min_895B3076E3BA6027.js", ENDITEM, 
		"Url=receiver/images/1x/folder_template_C13BB96DEBC9F30F.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/images/1x/CitrixReceiver_WebScreen_CBE548FB8FEE049E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/images/common/ReceiverFullScreenBackground_46E559C0E6B5A27B.jpg", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=custom/strings.en.js", ENDITEM, 
		"Url=custom/script.js", ENDITEM, 
		"Url=receiver/images/1x/viewSprite_B2F322BDCB824FAF.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/images/common/authspinner_B0BCD339560CA593.gif", ENDITEM, 
		"Url=receiver/images/common/icon_loading_9A0623127A028FEB.png", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2JHRnhlRmhYYmtwdmJqbFVWV3hwVlZaV1EyOXBlbmxITTI5QlBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2NFTm9NM1JKUnpObVZFTnpORXhRTUUxT2EyY3lVa3N5TXl0alBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL1duZHhaRlZXV0VWTWRuYzNPRGw2VEhWUUsyRkNTSE5WYVhoclBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL00zZE9NVWROUmtWMFQwZDBhME5yWVRJM2NsaDBia04yUTFkU1QxbFNkVGhXU1ZWQlRXWlNWbFJpZHowLS9pbWFnZQ--?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2NqTTJXVmxLZW1OTFNISnJWREJMZG5GbGRWbGxTVGNyTVRFMFBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL1UxZFNOblpTYkhaRmVUbEJNRzAzTjB3MWNHRkRLMUIyYm1zNFBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		LAST);

	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_custom_request("Configuration", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Home/Configuration", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=", 
		EXTRARES, 
		"Url=https://clients1.google.com/tbproxy/af/query?q=Chc2LjEuMTcxNS4xNDQyL2VuIChHR0xMKRMZtxZWN-1XI8ojLXBB36gkIy0pLWCOJBQ=", "Referer=", ENDITEM, 
		LAST);

	web_add_auto_header("Csrf-Token", 
		"00F187324331B7081FC84E5B3A38B9C8");

	web_custom_request("GetDetectionTicket", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionTicket", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_submit_data("GetDetectionStatus", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionStatus", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=ticket", "Value=CDT_FGthj8fPEQT8OPdBhXuGLLikRJz1Uo6OkJgmxJQPK0CEUdmmVW8MQh5WtjsSDC9s", ENDITEM, 
		LAST);

	web_submit_data("GetDetectionStatus_2", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionStatus", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=ticket", "Value=CDT_FGthj8fPEQT8OPdBhXuGLLikRJz1Uo6OkJgmxJQPK0CEUdmmVW8MQh5WtjsSDC9s", ENDITEM, 
		LAST);

	web_add_cookie("CtxsUserPreferredClient=Native; DOMAIN=storefront.smileco.com");

	web_add_cookie("CtxsClientDetectionDone=true; DOMAIN=storefront.smileco.com");

	web_add_cookie("CtxsHasUpgradeBeenShown=true; DOMAIN=storefront.smileco.com");

	web_submit_data("List", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/List", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=format", "Value=json", ENDITEM, 
		"Name=resourceDetails", "Value=Default", ENDITEM, 
		LAST);

	web_custom_request("GetAuthMethods", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/GetAuthMethods", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("Login", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/Login", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/vnd.citrix.authenticateresponse-1+xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=", 
		EXTRARES, 
		"Url=../receiver/images/1x/CitrixStoreFront_auth_14B96BFF2B0A6FF8.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=https://clients1.google.com/tbproxy/af/query?q=Chc2LjEuMTcxNS4xNDQyL2VuIChHR0xMKRMZvqVRrhN9bbIjLeeNQA4kIy3OQUx6JBQ=", "Referer=", ENDITEM, 
		LAST);

	web_revert_auto_header("Csrf-Token");

	web_revert_auto_header("X-Citrix-IsUsingHTTPS");

	web_revert_auto_header("X-Requested-With");

	web_submit_data("reportDetectionStatus", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClub/clientAssistant/reportDetectionStatus", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=ticket", "Value=CDT_FGthj8fPEQT8OPdBhXuGLLikRJz1Uo6OkJgmxJQPK0CEUdmmVW8MQh5WtjsSDC9s", ENDITEM, 
		"Name=protocolVersion", "Value=1", ENDITEM, 
		"Name=hdxVersion", "Value=14.7.0.13011", ENDITEM, 
		"Name=hdxIsPassthrough", "Value=False", ENDITEM, 
		"Name=hdxIsPassthroughVariable", "Value=False", ENDITEM, 
		EXTRARES, 
		"Url=/Citrix/SmileDirectClubWeb/receiver/images/1x/spinner_white_auth_button_53FD5A337A529DA7.gif", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		LAST);

	lr_start_transaction("Login");

	web_add_auto_header("Csrf-Token", 
		"00F187324331B7081FC84E5B3A38B9C8");

	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_data("LoginAttempt", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/LoginAttempt", 
		"Method=POST", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=username", "Value=Crtest.user12", ENDITEM, 
		"Name=password", "Value=P@$$word12", ENDITEM, 
		"Name=saveCredentials", "Value=false", ENDITEM, 
		"Name=loginBtn", "Value=Log On", ENDITEM, 
		"Name=StateContext", "Value=", ENDITEM, 
		LAST);

	web_add_cookie("CtxsPasswordChangeAllowed=true; DOMAIN=storefront.smileco.com");

	web_submit_data("List_2", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/List", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=format", "Value=json", ENDITEM, 
		"Name=resourceDetails", "Value=Default", ENDITEM, 
		EXTRARES, 
		"Url=../receiver/images/1x/CitrixReceiverLogo_Home_5C24BCEC5A182425.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/spinner_5CF0D1C8A76AAC8E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/ico_search_E84E3D63D821F80D.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/search_close_BC5A22358E58905F.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		LAST);

	web_custom_request("GetUserName", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/GetUserName", 
		"Method=POST", 
		"Resource=0", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("AllowSelfServiceAccountManagement", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/AllowSelfServiceAccountManagement", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	lr_end_transaction("Login",LR_AUTO);

	lr_think_time(13);

	lr_start_transaction("Clcik_VDI");

	web_submit_data("WGVuRGVza3RvcCBDb250cm9sbGVyLkNBRFBlcmZvcm1hbmNlICRTODEtMTQ0", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/GetLaunchStatus/WGVuRGVza3RvcCBDb250cm9sbGVyLkNBRFBlcmZvcm1hbmNlICRTODEtMTQ0", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=displayNameDesktopTitle", "Value=CADPerformance", ENDITEM, 
		"Name=createFileFetchTicket", "Value=false", ENDITEM, 
		EXTRARES, 
		"Url=https://safebrowsing.googleapis.com/v4/threatListUpdates:fetch?$req="
		"Ch0KDGdvb2dsZWNocm9tZRINNzYuMC4zODA5LjEzMhopCAUQARobCg0IBRAGGAEiAzAwMTABEJKZBxoCGAVGOGlKIgQgASACKAEaKQgBEAEaGwoNCAEQBhgBIgMwMDEwARD7uwYaAhgF0X5_qCIEIAEgAigBGikIBxABGhsKDQgHEAYYASIDMDAxMAEQooQGGgIYBYnOz40iBCABIAIoARonCAEQARoZCg0IARAGGAEiAzAwMTADEBQaAhgFWvtz7SIEIAEgAigDGigIARAIGhoKDQgBEAgYASIDMDAxMAQQoRgaAhgFUEuYUyIEIAEgAigEGicICRABGhkKDQgJEAYYASIDMDAxMAYQAhoCGAUpMKEkIgQgASACKAYaKAgPEAEaGgoNCA8QBhgBIgMwMDEwARC6BRoCGAW0XPlHIgQgASACKAEaJwgJEAEaGQoNCAkQBhgBIgMwMDEwARAVGgIYBddYphwiBCABIAIoARonCAoQCBoZCg"
		"0IChAIGAEiAzAwMTABEAUaAhgFYb4sSiIEIAEgAigBGigICBABGhoKDQgIEAYYASIDMDAxMAEQ5gYaAhgFlH-ZGSIEIAEgAigBGigIDRABGhoKDQgNEAYYASIDMDAxMAEQn0saAhgFSPIcMCIEIAEgAigBGikIAxABGhsKDQgDEAYYASIDMDAxMAEQn70GGgIYBcylb3IiBCABIAIoARopCA4QARobCg0IDhAGGAEiAzAwMTABEKKiAhoCGAWXXsrKIgQgASACKAEiAggB&$ct=application/x-protobuf&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", "Referer=", ENDITEM, 
		LAST);

	ctrx_nfuse_connect("https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/LaunchIca/WGVuRGVza3RvcCBDb250cm9sbGVyLkNBRFBlcmZvcm1hbmNlICRTODEtMTQ0.ica?CsrfToken=00F187324331B7081FC84E5B3A38B9C8&IsUsingHttps=Yes&displayNameDesktopTitle=CADPerformance&launchId=1568972944857", CTRX_LAST);

	lr_end_transaction("Clcik_VDI",LR_AUTO);

	lr_start_transaction("Open_VDI");

	ctrx_wait_for_event("LOGON", CTRX_LAST);

	lr_end_transaction("Open_VDI",LR_AUTO);

	lr_start_transaction("Open_CAD");

	ctrx_mouse_double_click(28, 231, LEFT_BUTTON, 0, "NULL", CTRX_LAST);

	lr_end_transaction("Open_CAD",LR_AUTO);

	lr_start_transaction("Patient_files");

	ctrx_sync_on_window("CA Digital - CA Digital", ACTIVATE, 0, 0, 1281, 985, "", CTRX_LAST);

	ctrx_mouse_click(313, 651, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	lr_end_transaction("Patient_files",LR_AUTO);

	lr_start_transaction("Create");

	ctrx_mouse_click(886, 765, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	lr_end_transaction("Create",LR_AUTO);

	lr_start_transaction("Patient_details");

	ctrx_mouse_click(1194, 259, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_type("CADP456123", "", CTRX_LAST);

	ctrx_mouse_click(1130, 307, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_type("CADF456123", "", CTRX_LAST);

	ctrx_mouse_click(1121, 343, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_type("CADL456123", "", CTRX_LAST);

	lr_think_time(15);

	ctrx_mouse_click(1136, 380, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_type("01/07/1986", "", CTRX_LAST);

	ctrx_mouse_click(1139, 424, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_type("MRN456123", "", CTRX_LAST);

	ctrx_mouse_click(1128, 499, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_type("09/20/19", "", CTRX_LAST);

	lr_think_time(5);

	ctrx_mouse_click(1165, 502, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_type("201", "", CTRX_LAST);

	ctrx_key("DELETE_KEY", 0, "", CTRX_LAST);

	ctrx_mouse_click(1204, 904, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	web_revert_auto_header("Csrf-Token");

	web_revert_auto_header("X-Citrix-IsUsingHTTPS");

	web_revert_auto_header("X-Requested-With");

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=9:1350976994&cup2hreq=b4983c3d9afa346c2ca73cbf1e6b91f396b4d17256c25b95205bfc68d73d347f", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx2,crx3\",\"app\":[{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"GCEB\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{61256212-ed7b-4ab4-b7b8-dc2289b1fca8}\",\"rd\":4645},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"GCEB\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{3e048032-a25c-42ef-aae1-56feba364a43}\",\"rd\":4645},\"updatecheck\":{},\""
		"version\":\"4.10.1440.18\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"GCEB\",\"cohort\":\"1:bm1:sbl@0.01,sf3@0.1\",\"cohorthint\":\"M54ToM99\",\"cohortname\":\"M54ToM99\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.72ae053d74e3a8df90460d740b8e33a80ba24509b65fddb66f53609aecdbbcf7\"}]},\"ping\":{\"ping_freshness\":\"{87f0277d-6928-48cd-aa6d-d4544faea1ab}\",\"rd\":4645},\"updatecheck\":{},\"version\":\"9.4.1\"},{\"appid\":\"mimojjlkmoijpicakmndhoigimigcmbb\",\"brand\":\""
		"GCEB\",\"cohort\":\"1:d0j:\",\"cohorthint\":\"Chrome [M50... M99]\",\"cohortname\":\"Chrome [M50... M99]\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.92d2e1183317fff87c7bcdccfbb5da46bfa0ab42cf17ba18d37424c8b084e5e5\"}]},\"ping\":{\"ping_freshness\":\"{36f5893b-2c01-478e-995a-aa13b5dbe499}\",\"rd\":4645},\"updatecheck\":{},\"version\":\"32.0.0.255\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"GCEB\",\"enabled\":true,\"ping\":{\"ping_freshness\":\""
		"{40b06dc0-e7e4-4808-b5bf-8bc1ac11ddc5}\",\"rd\":4645},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"hnimpnehoodheedghdeeijklkeaacbdc\",\"brand\":\"GCEB\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.6f6bc93dcd62dc251850d2ff458fda96083ceb7fbe8eeb11248b8485ef2aea23\"}]},\"ping\":{\"ping_freshness\":\"{603dbd69-1cca-4912-bc7f-87db621e5bf0}\",\"rd\":4645},\"updatecheck\":{},\"version\":\"0.57.44.2492\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"GCEB\",\"cohort\""
		":\"1:jcl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.5da0134e93c5ad22e6ef49073484ec6b22f8e7f5a26f3768fd50a180d126517b\"}]},\"ping\":{\"ping_freshness\":\"{ce45ffb7-36ed-4146-ae35-a5da00bc8f19}\",\"rd\":4645},\"updatecheck\":{},\"version\":\"5408\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"GCEB\",\"cohort\":\"1:cux:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":"
		"\"1.fd49e95c952bdb265a80513767311a5e069ac9dbf2ed4b480b96513b0ccbe086\"}]},\"ping\":{\"ping_freshness\":\"{0ce6c7de-2697-43ad-98f9-cc29cbc1c4ed}\",\"rd\":4645},\"updatecheck\":{},\"version\":\"36\"},{\"appid\":\"aemomkdncapdnfajjbbcbdebjljbpmpj\",\"brand\":\"GCEB\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{3f7f7d58-a371-4c4e-9616-a6d2df8ada32}\",\"rd\":4645},\"updatecheck\":{},\"version\":\"1.0.5.0\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"GCEB\",\"cohort\":\"1:j5l:\",\""
		"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.3eb16d6c28b502ac4cfee8f4a148df05f4d93229fa36a71db8b08d06329ff18a\"}]},\"ping\":{\"ping_freshness\":\"{a63b81bc-219e-493b-a05e-cee471b2c286}\",\"rd\":4645},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"gkmgaooipdjhmangpemjhigmamcehddo\",\"brand\":\"GCEB\",\"cohort\":\"1:pw3:\",\"cohorthint\":\"Stable\",\"cohortname\":\"Stable\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.50eb942123306754a5cb3a9cd93e3357c4af94b7fd78226f21148e513c5c1ec9\"}]},\"ping\":{\"ping_freshness\":\"{562cbb9d-6850-4d54-97fd-defb0f2317ea}\",\"rd\":4645},\"tag\":\"eset_exp_b\",\"updatecheck\":{},\"version\":\"44.219.200\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"GCEB\",\"cohort\":\"1:ofl:\",\"cohorthint\":\"stable64\",\"cohortname\":\"stable64\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\""
		"ping\":{\"ping_freshness\":\"{b8488076-ff6d-47ab-bd39-848a585adddd}\",\"rd\":4645},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\"copjbmjbojbakpaedmpkhmiplmmehfck\",\"brand\":\"GCEB\",\"cohort\":\"1:p1x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.207921137eee9c0831e0bd890330986c10dfd9382034491b82de3f86ae6915f7\"}]},\"ping\":{\"ping_freshness\":\"{1bf67f01-3982-4a9a-99a8-48b0ccdec0ac}\",\"rd\":4645},\"updatecheck\":{},\""
		"version\":\"2018.9.6.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":true,\"hw\":{\"physmemory\":32},\"lang\":\"en-US\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.14393.3204\"},\"prodversion\":\"76.0.3809.132\",\"protocol\":\"3.1\",\"requestid\":\"{86cfc8e9-0d4e-47b1-941f-23ddc4027a26}\",\"sessionid\":\"{50bbb094-00a9-4c8c-80ca-2bdd146f0c62}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\""
		"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.34.11\"},\"updaterversion\":\"76.0.3809.132\"}}", 
		LAST);

	lr_end_transaction("Patient_details",LR_AUTO);

	lr_think_time(27);

	lr_start_transaction("Import_stl_files");

	ctrx_mouse_click(245, 58, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_sync_on_window("Load document...", ACTIVATE, 415, 309, 450, 364, "", CTRX_LAST);

	ctrx_mouse_click(429, 211, LEFT_BUTTON, 0, "Load document...", CTRX_LAST);

	ctrx_sync_on_window("Open", ACTIVATE, 220, 272, 841, 433, "", CTRX_LAST);

	ctrx_mouse_click(64, 325, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_double_click(155, 207, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(815, 345, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	lr_think_time(4);

	ctrx_mouse_click(815, 345, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(815, 345, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	lr_think_time(4);

	ctrx_mouse_click(454, 101, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(767, 373, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(167, 133, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(793, 374, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(192, 116, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(770, 377, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(411, 78, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(772, 372, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	lr_think_time(22);

	ctrx_sync_on_window("Load document...", ACTIVATE, 415, 309, 450, 364, "", CTRX_LAST);

	ctrx_mouse_click(429, 249, LEFT_BUTTON, 0, "Load document...", CTRX_LAST);

	ctrx_sync_on_window("Open", ACTIVATE, 220, 272, 841, 433, "", CTRX_LAST);

	ctrx_mouse_click(408, 100, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(795, 377, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	lr_think_time(4);

	ctrx_sync_on_window("Load document...", ACTIVATE, 415, 309, 450, 364, "", CTRX_LAST);

	ctrx_mouse_click(224, 338, LEFT_BUTTON, 0, "Load document...", CTRX_LAST);

	lr_end_transaction("Import_stl_files",LR_AUTO);

	lr_think_time(45);

	lr_start_transaction("Open_impressions");

	ctrx_sync_on_window("CA Digital - CA Digital", ACTIVATE, 0, 0, 1281, 985, "", CTRX_LAST);

	ctrx_mouse_click(269, 278, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_mouse_double_click(270, 278, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_mouse_up(270, 278, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	lr_end_transaction("Open_impressions",LR_AUTO);

	lr_think_time(26);

	lr_start_transaction("Step1");

	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, 0, 0, 1281, 985, "", CTRX_LAST);

	ctrx_mouse_click(651, 183, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_end_transaction("Step1",LR_AUTO);

	lr_think_time(134);

	lr_start_transaction("step2");

	ctrx_mouse_click(126, 137, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(29);

	ctrx_mouse_click(792, 525, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(954, 522, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(790, 628, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(952, 628, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(5);

	ctrx_mouse_click(139, 483, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(153, 429, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(68);

	ctrx_mouse_click(168, 389, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(189, 348, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(196, 310, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(220, 280, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(257, 268, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(302, 266, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(339, 279, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(4);

	ctrx_mouse_click(366, 301, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(376, 342, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(395, 377, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(414, 425, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(424, 478, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(151, 673, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(17);

	ctrx_mouse_click(167, 725, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(188, 775, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(202, 808, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(221, 838, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(237, 863, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(265, 855, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(7);

	ctrx_mouse_click(293, 854, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(325, 863, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(343, 841, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(10);

	ctrx_mouse_click(362, 815, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(19);

	ctrx_mouse_click(377, 778, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(397, 734, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(416, 680, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(17);

	ctrx_mouse_click(810, 577, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_end_transaction("step2",LR_AUTO);

	lr_think_time(50);

	lr_start_transaction("Step3");

	ctrx_mouse_click(180, 131, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(98);

	ctrx_mouse_click(790, 191, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(755, 235, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(9);

	ctrx_mouse_click(58, 296, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(32);

	ctrx_mouse_click(431, 716, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(12);

	ctrx_mouse_click(633, 710, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(8);

	ctrx_mouse_click(408, 347, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(30);

	ctrx_mouse_down(460, 344, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_up(465, 344, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(47);

	ctrx_mouse_down(392, 342, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_up(388, 342, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(6);

	ctrx_mouse_down(424, 304, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_up(413, 306, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(6);

	ctrx_mouse_click(459, 330, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_end_transaction("Step3",LR_AUTO);

	lr_think_time(14);

	lr_start_transaction("Step4");

	ctrx_mouse_click(245, 124, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	web_add_cookie("CtxsDesktopAutoLaunchDone=no; DOMAIN=storefront.smileco.com");

	web_add_header("Csrf-Token", 
		"00F187324331B7081FC84E5B3A38B9C8");

	web_add_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	lr_think_time(24);

	web_custom_request("Logoff", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/Logoff", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	lr_end_transaction("Step4",LR_AUTO);

	lr_think_time(27);

	lr_start_transaction("Export_stl_files");

	ctrx_mouse_click(57, 917, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(6);

	ctrx_sync_on_window("Save", ACTIVATE, 200, 273, 882, 433, "", CTRX_LAST);

	ctrx_mouse_click(847, 213, LEFT_BUTTON, 0, "Save", CTRX_LAST);

	ctrx_sync_on_window("Select Export File Types", ACTIVATE, 508, 391, 265, 201, "", CTRX_LAST);

	ctrx_mouse_click(24, 83, LEFT_BUTTON, 0, "Select Export File Types", CTRX_LAST);

	ctrx_mouse_click(22, 51, LEFT_BUTTON, 0, "Select Export File Types", CTRX_LAST);

	ctrx_mouse_click(52, 173, LEFT_BUTTON, 0, "Select Export File Types", CTRX_LAST);

	ctrx_sync_on_window("Save", ACTIVATE, 200, 273, 882, 433, "", CTRX_LAST);

	ctrx_mouse_click(60, 255, LEFT_BUTTON, 0, "Save", CTRX_LAST);

	lr_think_time(5);

	ctrx_mouse_click(66, 175, LEFT_BUTTON, 0, "Save", CTRX_LAST);

	ctrx_mouse_click(821, 374, LEFT_BUTTON, 0, "Save", CTRX_LAST);

	lr_end_transaction("Export_stl_files",LR_AUTO);

	lr_think_time(119);

	lr_start_transaction("Close_CAD");

	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, 0, 0, 1281, 985, "", CTRX_LAST);

	ctrx_mouse_click(1255, 10, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_end_transaction("Close_CAD",LR_AUTO);

	lr_start_transaction("Close_Citrix");

	ctrx_logoff(CTRX_NORMAL_LOGOFF, CTRX_LAST);

	lr_end_transaction("Close_Citrix",LR_AUTO);

	return 0;
}