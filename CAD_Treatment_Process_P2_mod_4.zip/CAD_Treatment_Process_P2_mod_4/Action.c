Action()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=76", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://ssl.gstatic.com/safebrowsing/csd/client_model_v5_variation_0.pb", "Referer=", ENDITEM, 
		"Url=https://ssl.gstatic.com/safebrowsing/csd/client_model_v5_ext_variation_0.pb", "Referer=", ENDITEM, 
		LAST);

	lr_think_time(14);

	web_url("SmileDirectClubWeb", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/js/external/jquery.dotdotdot.min_08EE54CBA886AD0A.js", ENDITEM, 
		"Url=custom/style.css", ENDITEM, 
		"Url=receiver/js/external/velocity.min_B218502A82F66680.js", ENDITEM, 
		"Url=receiver/js/external/slick.min_FEB62CC230E2BA2A.js", ENDITEM, 
		"Url=receiver/js/external/hammer.v2.0.8.min_F699A1E56189259A.js", ENDITEM, 
		"Url=receiver/js/ctxs.core.min_33B1CC992A07D57E.js", ENDITEM, 
		"Url=receiver/images/1x/CitrixReceiver_WebScreen_CBE548FB8FEE049E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/images/1x/actionSprite_531B7A6FF85CA98E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/images/1x/folder_template_C13BB96DEBC9F30F.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/js/ctxs.webui.min_895B3076E3BA6027.js", ENDITEM, 
		"Url=receiver/images/common/ReceiverFullScreenBackground_46E559C0E6B5A27B.jpg", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=custom/script.js", ENDITEM, 
		"Url=custom/strings.en.js", ENDITEM, 
		"Url=receiver/images/1x/viewSprite_B2F322BDCB824FAF.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/images/common/authspinner_B0BCD339560CA593.gif", ENDITEM, 
		"Url=receiver/images/common/icon_loading_9A0623127A028FEB.png", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2NFTm9NM1JKUnpObVZFTnpORXhRTUUxT2EyY3lVa3N5TXl0alBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2JHRnhlRmhYYmtwdmJqbFVWV3hwVlZaV1EyOXBlbmxITTI5QlBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2NqTTJXVmxLZW1OTFNISnJWREJMZG5GbGRWbGxTVGNyTVRFMFBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL1duZHhaRlZXV0VWTWRuYzNPRGw2VEhWUUsyRkNTSE5WYVhoclBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL1UxZFNOblpTYkhaRmVUbEJNRzAzTjB3MWNHRkRLMUIyYm1zNFBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL00zZE9NVWROUmtWMFQwZDBhME5yWVRJM2NsaDBia04yUTFkU1QxbFNkVGhXU1ZWQlRXWlNWbFJpZHowLS9pbWFnZQ--?size=128", ENDITEM, 
		LAST);

	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

/*Correlation comment: Automatic rules - Do not change!  
Original value='76B45D668433E67467994FFDA92F3AB5' 
Name ='CitrixXenApp_CsrfToken' 
Type ='Rule' 
AppName ='Citrix_XenApp' 
RuleName ='CsrfToken'*/
	web_reg_save_param_ex(
		"ParamName=CitrixXenApp_CsrfToken",
		"LB/IC=CsrfToken=",
		"RB/IC=;",
		SEARCH_FILTERS,
		"Scope=Cookies",
		LAST);

	web_custom_request("Configuration", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Home/Configuration", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=", 
		EXTRARES, 
		"Url=https://clients1.google.com/tbproxy/af/query?q=Chc2LjEuMTcxNS4xNDQyL2VuIChHR0xMKRMZtxZWN-1XI8ojLXBB36gkIy0pLWCOJBQ=", "Referer=", ENDITEM, 
		LAST);

	web_add_auto_header("Csrf-Token",
		"{CitrixXenApp_CsrfToken}");

	web_custom_request("GetDetectionTicket", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionTicket", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_submit_data("GetDetectionStatus", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionStatus", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=ticket", "Value=CDT_4DPILwDxB0WBzsMNcT_BWrikRJz1Uo6OkJgmxJQPK0CEUdmmVW8MQh5WtjsSDC9s", ENDITEM, 
		LAST);

	web_submit_data("GetDetectionStatus_2", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionStatus", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=ticket", "Value=CDT_4DPILwDxB0WBzsMNcT_BWrikRJz1Uo6OkJgmxJQPK0CEUdmmVW8MQh5WtjsSDC9s", ENDITEM, 
		LAST);

	web_add_cookie("CtxsUserPreferredClient=Native; DOMAIN=storefront.smileco.com");

	web_add_cookie("CtxsClientDetectionDone=true; DOMAIN=storefront.smileco.com");

	web_add_cookie("CtxsHasUpgradeBeenShown=true; DOMAIN=storefront.smileco.com");

	web_submit_data("List", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/List", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=format", "Value=json", ENDITEM, 
		"Name=resourceDetails", "Value=Default", ENDITEM, 
		LAST);

	web_custom_request("GetAuthMethods", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/GetAuthMethods", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("Login", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/Login", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/vnd.citrix.authenticateresponse-1+xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"EncType=", 
		EXTRARES, 
		"Url=../receiver/images/1x/CitrixStoreFront_auth_14B96BFF2B0A6FF8.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=https://clients1.google.com/tbproxy/af/query?q=Chc2LjEuMTcxNS4xNDQyL2VuIChHR0xMKRMZvqVRrhN9bbIjLeeNQA4kIy3OQUx6JBQ=", "Referer=", ENDITEM, 
		LAST);

	web_revert_auto_header("Csrf-Token");

	web_revert_auto_header("X-Citrix-IsUsingHTTPS");

	web_revert_auto_header("X-Requested-With");

	web_submit_data("reportDetectionStatus", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClub/clientAssistant/reportDetectionStatus", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=ticket", "Value=CDT_4DPILwDxB0WBzsMNcT_BWrikRJz1Uo6OkJgmxJQPK0CEUdmmVW8MQh5WtjsSDC9s", ENDITEM, 
		"Name=protocolVersion", "Value=1", ENDITEM, 
		"Name=hdxVersion", "Value=14.7.0.13011", ENDITEM, 
		"Name=hdxIsPassthrough", "Value=False", ENDITEM, 
		"Name=hdxIsPassthroughVariable", "Value=False", ENDITEM, 
		EXTRARES, 
		"Url=/Citrix/SmileDirectClubWeb/receiver/images/1x/spinner_white_auth_button_53FD5A337A529DA7.gif", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		LAST);

	lr_start_transaction("Login");

	web_add_auto_header("Csrf-Token",
		"{CitrixXenApp_CsrfToken}");

	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_data("LoginAttempt", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/LoginAttempt", 
		"Method=POST", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=username", "Value=Crtest.user16", ENDITEM, 
		"Name=password", "Value=P@$$word16", ENDITEM, 
		"Name=saveCredentials", "Value=false", ENDITEM, 
		"Name=loginBtn", "Value=Log On", ENDITEM, 
		"Name=StateContext", "Value=", ENDITEM, 
		LAST);

	web_add_cookie("CtxsPasswordChangeAllowed=true; DOMAIN=storefront.smileco.com");

	web_submit_data("List_2", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/List", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=format", "Value=json", ENDITEM, 
		"Name=resourceDetails", "Value=Default", ENDITEM, 
		EXTRARES, 
		"Url=../receiver/images/1x/CitrixReceiverLogo_Home_5C24BCEC5A182425.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/spinner_5CF0D1C8A76AAC8E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/ico_search_E84E3D63D821F80D.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/search_close_BC5A22358E58905F.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		LAST);

	web_custom_request("GetUserName", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/GetUserName", 
		"Method=POST", 
		"Resource=0", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("AllowSelfServiceAccountManagement", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/AllowSelfServiceAccountManagement", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	lr_end_transaction("Login",LR_AUTO);

	lr_think_time(14);

	lr_start_transaction("Clcik_VDI");

	web_submit_data("WGVuRGVza3RvcCBDb250cm9sbGVyLkNBRFBlcmZvcm1hbmNlICRTODEtMTQ0", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/GetLaunchStatus/WGVuRGVza3RvcCBDb250cm9sbGVyLkNBRFBlcmZvcm1hbmNlICRTODEtMTQ0", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=displayNameDesktopTitle", "Value=CADPerformance", ENDITEM, 
		"Name=createFileFetchTicket", "Value=false", ENDITEM, 
		EXTRARES, 
		"Url=https://safebrowsing.googleapis.com/v4/threatListUpdates:fetch?$req="
		"Ch0KDGdvb2dsZWNocm9tZRINNzYuMC4zODA5LjEzMhopCAUQARobCg0IBRAGGAEiAzAwMTABEJSZBxoCGAWhAHyrIgQgASACKAEaKQgBEAEaGwoNCAEQBhgBIgMwMDEwARD9uwYaAhgFV7N9ciIEIAEgAigBGikIBxABGhsKDQgHEAYYASIDMDAxMAEQpIQGGgIYBQrhcS8iBCABIAIoARonCAEQARoZCg0IARAGGAEiAzAwMTADEBQaAhgFWvtz7SIEIAEgAigDGigIARAIGhoKDQgBEAgYASIDMDAxMAQQoRgaAhgFUEuYUyIEIAEgAigEGicICRABGhkKDQgJEAYYASIDMDAxMAYQAhoCGAUpMKEkIgQgASACKAYaKAgPEAEaGgoNCA8QBhgBIgMwMDEwARC7BRoCGAX6p5rPIgQgASACKAEaJwgJEAEaGQoNCAkQBhgBIgMwMDEwARAVGgIYBddYphwiBCABIAIoARonCAoQCBoZCg"
		"0IChAIGAEiAzAwMTABEAUaAhgFYb4sSiIEIAEgAigBGigICBABGhoKDQgIEAYYASIDMDAxMAEQ5gYaAhgFlH-ZGSIEIAEgAigBGigIDRABGhoKDQgNEAYYASIDMDAxMAEQoEsaAhgFZGWLYSIEIAEgAigBGikIAxABGhsKDQgDEAYYASIDMDAxMAEQn70GGgIYBcylb3IiBCABIAIoARopCA4QARobCg0IDhAGGAEiAzAwMTABEKSiAhoCGAWfHiFeIgQgASACKAEiAggB&$ct=application/x-protobuf&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", "Referer=", ENDITEM, 
		LAST);

	ctrx_nfuse_connect("https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/LaunchIca/WGVuRGVza3RvcCBDb250cm9sbGVyLkNBRFBlcmZvcm1hbmNlICRTODEtMTQ0.ica?CsrfToken={CitrixXenApp_CsrfToken}&IsUsingHttps=Yes&displayNameDesktopTitle=CADPerformance&launchId=1568975765705", CTRX_LAST);

	lr_end_transaction("Clcik_VDI",LR_AUTO);

	lr_start_transaction("Open_VDI");

	ctrx_wait_for_event("LOGON", CTRX_LAST);

	lr_end_transaction("Open_VDI",LR_AUTO);

	lr_think_time(7);

	lr_start_transaction("Open_CAD");

	ctrx_mouse_double_click(48, 236, LEFT_BUTTON, 0, "NULL", CTRX_LAST);

	ctrx_mouse_up(48, 236, LEFT_BUTTON, 0, "Desktop", CTRX_LAST);

	lr_end_transaction("Open_CAD",LR_AUTO);

	lr_think_time(23);

	lr_start_transaction("Patient_files");

	ctrx_sync_on_window("CA Digital - CA Digital", ACTIVATE, 0, 0, 1281, 985, "", CTRX_LAST);

	ctrx_mouse_click(334, 640, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	lr_end_transaction("Patient_files",LR_AUTO);

	lr_think_time(11);

	lr_start_transaction("Create");

	ctrx_mouse_click(879, 753, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	lr_end_transaction("Create",LR_AUTO);

	lr_think_time(15);

	lr_start_transaction("Patient_details_save");

	ctrx_mouse_click(1169, 268, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_type("CADP254789", "", CTRX_LAST);

	ctrx_mouse_click(1163, 297, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_type("CADF254789", "", CTRX_LAST);

	ctrx_mouse_click(1138, 341, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_type("CADL254789", "", CTRX_LAST);

	ctrx_mouse_click(1131, 384, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_type("01/07/1986", "", CTRX_LAST);

	ctrx_mouse_click(1129, 417, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_type("MRN254789", "", CTRX_LAST);

	ctrx_mouse_click(1130, 503, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_type("09/20/2019", "", CTRX_LAST);

	ctrx_mouse_click(1184, 906, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	lr_end_transaction("Patient_details_save",LR_AUTO);

	lr_think_time(17);

	lr_start_transaction("Import_stl_files");

	ctrx_mouse_click(241, 57, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_sync_on_window("Load document...", ACTIVATE, 415, 309, 450, 364, "", CTRX_LAST);

	ctrx_mouse_click(430, 212, LEFT_BUTTON, 0, "Load document...", CTRX_LAST);

	ctrx_sync_on_window("Open", ACTIVATE, 220, 272, 841, 433, "", CTRX_LAST);

	ctrx_mouse_click(57, 336, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_double_click(162, 208, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_up(162, 208, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(817, 347, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(817, 347, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(817, 347, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(457, 98, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(764, 374, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(193, 131, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(761, 371, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(200, 133, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(197, 133, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(761, 375, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(332, 102, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(331, 97, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(785, 372, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_sync_on_window("Load document...", ACTIVATE, 415, 309, 450, 364, "", CTRX_LAST);

	ctrx_mouse_click(432, 252, LEFT_BUTTON, 0, "Load document...", CTRX_LAST);

	ctrx_sync_on_window("Open", ACTIVATE, 220, 272, 841, 433, "", CTRX_LAST);

	ctrx_mouse_click(348, 78, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(760, 381, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_sync_on_window("Load document...", ACTIVATE, 415, 309, 450, 364, "", CTRX_LAST);

	ctrx_mouse_click(230, 334, LEFT_BUTTON, 0, "Load document...", CTRX_LAST);

	lr_end_transaction("Import_stl_files",LR_AUTO);

	lr_think_time(48);

	lr_start_transaction("Open_Impressions");

	ctrx_sync_on_window("CA Digital - CA Digital", ACTIVATE, 0, 0, 1281, 985, "", CTRX_LAST);

	ctrx_mouse_double_click(280, 296, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	lr_end_transaction("Open_Impressions",LR_AUTO);

	lr_start_transaction("Step1");

	web_revert_auto_header("Csrf-Token");

	web_revert_auto_header("X-Citrix-IsUsingHTTPS");

	web_revert_auto_header("X-Requested-With");

	lr_think_time(29);

	web_custom_request("json", 
		"URL=http://update.googleapis.com/service/update2/json?cup2key=9:2296775069&cup2hreq=f86bd72913c7e393284a4674f58c71a070db017f61e39dd1f728497103d561ba", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx2,crx3\",\"app\":[{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"GCEB\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{53267efb-8aba-4682-abcb-f5f39779a12b}\",\"rd\":4645},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"GCEB\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{c371040d-a6e2-41c7-a655-d5d20ae2d04d}\",\"rd\":4645},\"updatecheck\":{},\""
		"version\":\"4.10.1440.18\"},{\"appid\":\"mimojjlkmoijpicakmndhoigimigcmbb\",\"brand\":\"GCEB\",\"cohort\":\"1:d0j:\",\"cohorthint\":\"Chrome [M50... M99]\",\"cohortname\":\"Chrome [M50... M99]\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.92d2e1183317fff87c7bcdccfbb5da46bfa0ab42cf17ba18d37424c8b084e5e5\"}]},\"ping\":{\"ping_freshness\":\"{3e0e4a21-e67f-4c10-be21-16fe9e2a22c7}\",\"rd\":4645},\"updatecheck\":{},\"version\":\"32.0.0.255\"},{\"appid\":\"hnimpnehoodheedghdeeijklkeaacbdc\","
		"\"brand\":\"GCEB\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.6f6bc93dcd62dc251850d2ff458fda96083ceb7fbe8eeb11248b8485ef2aea23\"}]},\"ping\":{\"ping_freshness\":\"{0356c245-6ee9-4710-957c-a3f1474e0287}\",\"rd\":4645},\"updatecheck\":{},\"version\":\"0.57.44.2492\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"GCEB\",\"cohort\":\"1:bm1:sbl@0.01,sf3@0.1\",\"cohorthint\":\"M54ToM99\",\"cohortname\":\"M54ToM99\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.72ae053d74e3a8df90460d740b8e33a80ba24509b65fddb66f53609aecdbbcf7\"}]},\"ping\":{\"ping_freshness\":\"{32b60c67-7efd-414d-b752-59d23dc6a175}\",\"rd\":4645},\"updatecheck\":{},\"version\":\"9.4.1\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"GCEB\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{73c1366c-da55-4f7b-aad2-cf14f6279895}\",\"rd\":4645},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"GCEB\",\"cohort\":\"1:cux:\","
		"\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.fd49e95c952bdb265a80513767311a5e069ac9dbf2ed4b480b96513b0ccbe086\"}]},\"ping\":{\"ping_freshness\":\"{c5645204-9bab-4f5d-bb52-5fe888832a6e}\",\"rd\":4645},\"updatecheck\":{},\"version\":\"36\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"GCEB\",\"cohort\":\"1:jcl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.5da0134e93c5ad22e6ef49073484ec6b22f8e7f5a26f3768fd50a180d126517b\"}]},\"ping\":{\"ping_freshness\":\"{7567cbc7-54a0-4841-9529-85f0167849c4}\",\"rd\":4645},\"updatecheck\":{},\"version\":\"5408\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"GCEB\",\"cohort\":\"1:j5l:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.3eb16d6c28b502ac4cfee8f4a148df05f4d93229fa36a71db8b08d06329ff18a\"}]},\"ping\":{\"ping_freshness\":\""
		"{430b85c6-8859-495b-bc49-1e1b2145651f}\",\"rd\":4645},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"aemomkdncapdnfajjbbcbdebjljbpmpj\",\"brand\":\"GCEB\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{f38d6ef5-551c-475c-9c6a-e2b19b7e7595}\",\"rd\":4645},\"updatecheck\":{},\"version\":\"1.0.5.0\"},{\"appid\":\"gkmgaooipdjhmangpemjhigmamcehddo\",\"brand\":\"GCEB\",\"cohort\":\"1:pw3:\",\"cohorthint\":\"Stable\",\"cohortname\":\"Stable\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.50eb942123306754a5cb3a9cd93e3357c4af94b7fd78226f21148e513c5c1ec9\"}]},\"ping\":{\"ping_freshness\":\"{d45a550c-a33e-4db8-bcfe-7d725e319708}\",\"rd\":4645},\"tag\":\"eset_exp_b\",\"updatecheck\":{},\"version\":\"44.219.200\"},{\"appid\":\"copjbmjbojbakpaedmpkhmiplmmehfck\",\"brand\":\"GCEB\",\"cohort\":\"1:p1x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.207921137eee9c0831e0bd890330986c10dfd9382034491b82de3f86ae6915f7\"}]},\"ping\":{\""
		"ping_freshness\":\"{78afc3a5-55fc-4f09-bd09-2e4756671ac1}\",\"rd\":4645},\"updatecheck\":{},\"version\":\"2018.9.6.0\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"GCEB\",\"cohort\":\"1:ofl:\",\"cohorthint\":\"stable64\",\"cohortname\":\"stable64\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\"{c072db8f-3948-4b12-948b-b07e93451f28}\",\"rd\":4645},\"updatecheck\":{},\""
		"version\":\"2018.8.8.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":true,\"hw\":{\"physmemory\":32},\"lang\":\"en-US\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.14393.3204\"},\"prodversion\":\"76.0.3809.132\",\"protocol\":\"3.1\",\"requestid\":\"{9ce69a60-1564-4bee-b82f-a626d64f7d47}\",\"sessionid\":\"{5127cdbd-1105-4930-b7eb-0ce928066956}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\""
		"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.34.11\"},\"updaterversion\":\"76.0.3809.132\"}}", 
		LAST);

	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, 0, 0, 1281, 985, "", CTRX_LAST);

	ctrx_mouse_click(639, 187, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_end_transaction("Step1",LR_AUTO);

	lr_think_time(15);

	lr_start_transaction("Step2");

	ctrx_mouse_click(119, 136, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(13);

	ctrx_mouse_click(793, 523, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(951, 523, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(794, 628, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(950, 627, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(19);

	ctrx_mouse_click(140, 474, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(153, 419, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(166, 369, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(179, 327, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(193, 291, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(232, 260, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(271, 248, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(320, 248, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(356, 263, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(396, 294, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(411, 337, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(424, 376, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(431, 424, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(446, 480, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(155, 673, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(171, 735, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(185, 788, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(196, 829, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(212, 867, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(242, 885, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(278, 895, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(310, 895, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(345, 881, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(371, 854, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(394, 821, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(408, 782, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(419, 732, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(436, 668, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(808, 568, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_end_transaction("Step2",LR_AUTO);

	lr_think_time(49);

	lr_start_transaction("Step3");

	ctrx_mouse_click(190, 129, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(95);

	ctrx_mouse_click(786, 181, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(737, 240, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(5);

	ctrx_mouse_click(54, 296, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(20);

	ctrx_mouse_click(207, 846, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(7);

	ctrx_mouse_down(229, 803, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(4);

	ctrx_mouse_up(239, 813, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(7);

	ctrx_mouse_down(231, 807, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_up(228, 804, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(12);

	ctrx_mouse_click(403, 310, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(4);

	ctrx_mouse_down(444, 282, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_up(445, 288, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(7);

	ctrx_mouse_down(432, 270, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_up(435, 273, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_end_transaction("Step3",LR_AUTO);

	lr_think_time(15);

	lr_start_transaction("Step4");

	ctrx_mouse_click(257, 138, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_end_transaction("Step4",LR_AUTO);

	lr_think_time(79);

	lr_start_transaction("Export_stLfiles");

	ctrx_mouse_click(48, 918, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(6);

	ctrx_sync_on_window("Save", ACTIVATE, 200, 273, 882, 433, "", CTRX_LAST);

	ctrx_mouse_click(64, 164, LEFT_BUTTON, 0, "Save", CTRX_LAST);

	ctrx_mouse_click(854, 212, LEFT_BUTTON, 0, "Save", CTRX_LAST);

	ctrx_sync_on_window("Select Export File Types", ACTIVATE, 508, 391, 265, 201, "", CTRX_LAST);

	ctrx_mouse_click(23, 82, LEFT_BUTTON, 0, "Select Export File Types", CTRX_LAST);

	ctrx_mouse_click(24, 51, LEFT_BUTTON, 0, "Select Export File Types", CTRX_LAST);

	ctrx_mouse_click(67, 174, LEFT_BUTTON, 0, "Select Export File Types", CTRX_LAST);

	ctrx_sync_on_window("Save", ACTIVATE, 200, 273, 882, 433, "", CTRX_LAST);

	ctrx_mouse_click(808, 376, LEFT_BUTTON, 0, "Save", CTRX_LAST);

	web_add_auto_header("Csrf-Token",
		"{CitrixXenApp_CsrfToken}");

	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	lr_think_time(98);

	web_custom_request("KeepAlive", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Home/KeepAlive", 
		"Method=HEAD", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Export_stLfiles",LR_AUTO);

	lr_think_time(15);

	lr_start_transaction("Home");

	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, 0, 0, 1281, 985, "", CTRX_LAST);

	ctrx_mouse_click(160, 67, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_end_transaction("Home",LR_AUTO);

	lr_think_time(18);

	lr_start_transaction("Close_CAD");

	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, 0, 0, 1281, 985, "", CTRX_LAST);

	ctrx_mouse_click(1254, 10, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(1254, 10, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_double_click(1254, 10, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_up(1254, 10, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_end_transaction("Close_CAD",LR_AUTO);

	lr_start_transaction("Close_Citrix");

	ctrx_logoff(CTRX_NORMAL_LOGOFF, CTRX_LAST);

	lr_end_transaction("Close_Citrix",LR_AUTO);

	lr_start_transaction("Logout");

	web_add_cookie("CtxsDesktopAutoLaunchDone=no; DOMAIN=storefront.smileco.com");

	lr_think_time(10);

	web_custom_request("Disconnect", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Sessions/Disconnect", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("Logoff", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/Logoff", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	lr_end_transaction("Logout",LR_AUTO);

	return 0;
}