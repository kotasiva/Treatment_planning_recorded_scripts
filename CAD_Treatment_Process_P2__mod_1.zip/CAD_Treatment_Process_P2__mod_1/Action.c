﻿Action()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=76", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://ssl.gstatic.com/safebrowsing/csd/client_model_v5_variation_0.pb", "Referer=", ENDITEM, 
		"Url=https://ssl.gstatic.com/safebrowsing/csd/client_model_v5_ext_variation_0.pb", "Referer=", ENDITEM, 
		LAST);

	lr_think_time(13);

	web_url("SmileDirectClubWeb", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=custom/style.css", ENDITEM, 
		"Url=receiver/js/external/hammer.v2.0.8.min_F699A1E56189259A.js", ENDITEM, 
		"Url=receiver/js/external/jquery.dotdotdot.min_08EE54CBA886AD0A.js", ENDITEM, 
		"Url=receiver/js/external/slick.min_FEB62CC230E2BA2A.js", ENDITEM, 
		"Url=receiver/js/external/velocity.min_B218502A82F66680.js", ENDITEM, 
		"Url=receiver/js/ctxs.core.min_33B1CC992A07D57E.js", ENDITEM, 
		"Url=receiver/js/ctxs.webui.min_895B3076E3BA6027.js", ENDITEM, 
		"Url=receiver/images/1x/actionSprite_531B7A6FF85CA98E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/images/1x/CitrixReceiver_WebScreen_CBE548FB8FEE049E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/images/1x/folder_template_C13BB96DEBC9F30F.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/images/common/ReceiverFullScreenBackground_46E559C0E6B5A27B.jpg", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=custom/script.js", ENDITEM, 
		"Url=custom/strings.en.js", ENDITEM, 
		"Url=receiver/images/1x/viewSprite_B2F322BDCB824FAF.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=receiver/images/common/authspinner_B0BCD339560CA593.gif", ENDITEM, 
		"Url=receiver/images/common/icon_loading_9A0623127A028FEB.png", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2NFTm9NM1JKUnpObVZFTnpORXhRTUUxT2EyY3lVa3N5TXl0alBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL1duZHhaRlZXV0VWTWRuYzNPRGw2VEhWUUsyRkNTSE5WYVhoclBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL00zZE9NVWROUmtWMFQwZDBhME5yWVRJM2NsaDBia04yUTFkU1QxbFNkVGhXU1ZWQlRXWlNWbFJpZHowLS9pbWFnZQ--?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL1UxZFNOblpTYkhaRmVUbEJNRzAzTjB3MWNHRkRLMUIyYm1zNFBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2JHRnhlRmhYYmtwdmJqbFVWV3hwVlZaV1EyOXBlbmxITTI5QlBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		"Url=Resources/Icon/L0NpdHJpeC9TbWlsZURpcmVjdENsdWIvcmVzb3VyY2VzL3YyL2NqTTJXVmxLZW1OTFNISnJWREJMZG5GbGRWbGxTVGNyTVRFMFBRLS0vaW1hZ2U-?size=128", ENDITEM, 
		LAST);

	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

/*Correlation comment: Automatic rules - Do not change!  
Original value='35AF8E174F2492D5C6115F5CF2CE6774' 
Name ='CitrixXenApp_CsrfToken' 
Type ='Rule' 
AppName ='Citrix_XenApp' 
RuleName ='CsrfToken'*/
	web_reg_save_param_ex(
		"ParamName=CitrixXenApp_CsrfToken",
		"LB/IC=CsrfToken=",
		"RB/IC=;",
		SEARCH_FILTERS,
		"Scope=Cookies",
		LAST);

	web_custom_request("Configuration", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Home/Configuration", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=", 
		EXTRARES, 
		"Url=https://clients1.google.com/tbproxy/af/query?q=Chc2LjEuMTcxNS4xNDQyL2VuIChHR0xMKRMZtxZWN-1XI8ojLXBB36gkIy0pLWCOJBQ=", "Referer=", ENDITEM, 
		LAST);

	web_add_auto_header("Csrf-Token",
		"{CitrixXenApp_CsrfToken}");

	lr_think_time(6);

	web_custom_request("GetDetectionTicket", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionTicket", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_submit_data("GetDetectionStatus", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ClientAssistant/GetDetectionStatus", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=ticket", "Value=CDT_4NY4BNBDUk1r8z_wwG0tkrikRJz1Uo6OkJgmxJQPK0CEUdmmVW8MQh5WtjsSDC9s", ENDITEM, 
		LAST);

	web_add_cookie("CtxsUserPreferredClient=Native; DOMAIN=storefront.smileco.com");

	web_add_cookie("CtxsClientDetectionDone=true; DOMAIN=storefront.smileco.com");

	web_add_cookie("CtxsHasUpgradeBeenShown=true; DOMAIN=storefront.smileco.com");

	web_submit_data("List", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/List", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=format", "Value=json", ENDITEM, 
		"Name=resourceDetails", "Value=Default", ENDITEM, 
		LAST);

	web_custom_request("GetAuthMethods", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/GetAuthMethods", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("Login", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/Login", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/vnd.citrix.authenticateresponse-1+xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=", 
		EXTRARES, 
		"Url=../receiver/images/1x/CitrixStoreFront_auth_14B96BFF2B0A6FF8.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=https://clients1.google.com/tbproxy/af/query?q=Chc2LjEuMTcxNS4xNDQyL2VuIChHR0xMKRMZvqVRrhN9bbIjLeeNQA4kIy3OQUx6JBQ=", "Referer=", ENDITEM, 
		LAST);

	web_revert_auto_header("Csrf-Token");

	web_revert_auto_header("X-Citrix-IsUsingHTTPS");

	web_revert_auto_header("X-Requested-With");

	lr_think_time(4);

	web_submit_data("reportDetectionStatus", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClub/clientAssistant/reportDetectionStatus", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=ticket", "Value=CDT_4NY4BNBDUk1r8z_wwG0tkrikRJz1Uo6OkJgmxJQPK0CEUdmmVW8MQh5WtjsSDC9s", ENDITEM, 
		"Name=protocolVersion", "Value=1", ENDITEM, 
		"Name=hdxVersion", "Value=14.7.0.13011", ENDITEM, 
		"Name=hdxIsPassthrough", "Value=False", ENDITEM, 
		"Name=hdxIsPassthroughVariable", "Value=False", ENDITEM, 
		EXTRARES, 
		"Url=/Citrix/SmileDirectClubWeb/receiver/images/1x/spinner_white_auth_button_53FD5A337A529DA7.gif", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		LAST);

	lr_start_transaction("Login");

	web_add_auto_header("Csrf-Token",
		"{CitrixXenApp_CsrfToken}");

	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_data("LoginAttempt", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/LoginAttempt", 
		"Method=POST", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=username", "Value=Crtest.user3", ENDITEM, 
		"Name=password", "Value=P@$$word3", ENDITEM, 
		"Name=saveCredentials", "Value=false", ENDITEM, 
		"Name=loginBtn", "Value=Log On", ENDITEM, 
		"Name=StateContext", "Value=", ENDITEM, 
		LAST);

	web_add_cookie("CtxsPasswordChangeAllowed=true; DOMAIN=storefront.smileco.com");

	web_submit_data("List_2", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/List", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=format", "Value=json", ENDITEM, 
		"Name=resourceDetails", "Value=Default", ENDITEM, 
		EXTRARES, 
		"Url=../receiver/images/1x/CitrixReceiverLogo_Home_5C24BCEC5A182425.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/spinner_5CF0D1C8A76AAC8E.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/ico_search_E84E3D63D821F80D.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		"Url=../receiver/images/1x/search_close_BC5A22358E58905F.png", "Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/receiver/css/ctxs.large-ui.min_62D11B01D15101DA.css", ENDITEM, 
		LAST);

	web_custom_request("GetUserName", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/GetUserName", 
		"Method=POST", 
		"Resource=0", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("AllowSelfServiceAccountManagement", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/ExplicitAuth/AllowSelfServiceAccountManagement", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	lr_end_transaction("Login",LR_AUTO);

	lr_think_time(44);

	lr_start_transaction("Click_VDI");

	web_submit_data("WGVuRGVza3RvcCBDb250cm9sbGVyLkNBRFBlcmZvcm1hbmNlICRTODEtMTQ0", 
		"Action=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/GetLaunchStatus/WGVuRGVza3RvcCBDb250cm9sbGVyLkNBRFBlcmZvcm1hbmNlICRTODEtMTQ0", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=displayNameDesktopTitle", "Value=CADPerformance", ENDITEM, 
		"Name=createFileFetchTicket", "Value=false", ENDITEM, 
		LAST);

	ctrx_nfuse_connect("https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Resources/LaunchIca/WGVuRGVza3RvcCBDb250cm9sbGVyLkNBRFBlcmZvcm1hbmNlICRTODEtMTQ0.ica?CsrfToken={CitrixXenApp_CsrfToken}&IsUsingHttps=Yes&displayNameDesktopTitle=CADPerformance&launchId=1568800464268", CTRX_LAST);

	lr_end_transaction("Click_VDI",LR_AUTO);

	lr_think_time(45);

	lr_start_transaction("Open_VDI");

	ctrx_wait_for_event("LOGON", CTRX_LAST);

	lr_end_transaction("Open_VDI",LR_AUTO);

	lr_think_time(40);

	lr_start_transaction("Open_CAD");

	ctrx_mouse_double_click(36, 229, LEFT_BUTTON, 0, "NULL", CTRX_LAST);

	lr_think_time(4);

	ctrx_sync_on_window("Desktop", ACTIVATE, 0, 0, 1281, 1025, "", CTRX_LAST);

	ctrx_mouse_double_click(49, 244, LEFT_BUTTON, 0, "Desktop", CTRX_LAST);

	lr_end_transaction("Open_CAD",LR_AUTO);

	lr_think_time(23);

	lr_start_transaction("Patinet_files");

	ctrx_sync_on_window("CA Digital - CA Digital", ACTIVATE, 0, 0, 1281, 985, "", CTRX_LAST);

	ctrx_mouse_click(352, 666, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	lr_end_transaction("Patinet_files",LR_AUTO);

	lr_think_time(13);

	lr_start_transaction("Create");

	ctrx_mouse_click(889, 754, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	lr_end_transaction("Create",LR_AUTO);

	lr_think_time(11);

	lr_start_transaction("Patient_details");

	ctrx_mouse_click(1130, 266, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_type("CADP78945789", "", CTRX_LAST);

	ctrx_mouse_click(1121, 309, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_type("CADF78945789", "", CTRX_LAST);

	ctrx_mouse_click(1127, 348, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_type("CADL78945789", "", CTRX_LAST);

	ctrx_mouse_click(1127, 380, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_type("01/07/1986", "", CTRX_LAST);

	ctrx_mouse_click(1126, 420, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_type("MRN78945789", "", CTRX_LAST);

	ctrx_mouse_click(1123, 504, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_type("09/18/2019", "", CTRX_LAST);

	ctrx_mouse_click(1192, 904, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	lr_end_transaction("Patient_details",LR_AUTO);

	lr_think_time(13);

	lr_start_transaction("Import_Stl_files");

	ctrx_mouse_click(243, 64, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	ctrx_sync_on_window("Load document...", ACTIVATE, 415, 309, 450, 364, "", CTRX_LAST);

	ctrx_mouse_click(429, 213, LEFT_BUTTON, 0, "Load document...", CTRX_LAST);

	lr_think_time(8);

	ctrx_sync_on_window("Open", ACTIVATE, 220, 272, 841, 433, "", CTRX_LAST);

	ctrx_mouse_click(68, 318, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_double_click(152, 206, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	lr_think_time(8);

	ctrx_mouse_click(819, 347, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(819, 347, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	lr_think_time(4);

	ctrx_mouse_click(748, 99, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(779, 377, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(174, 135, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(196, 131, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(169, 137, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(767, 368, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	lr_think_time(17);

	ctrx_mouse_double_click(192, 79, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(772, 377, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(407, 79, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(793, 379, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_sync_on_window("Load document...", ACTIVATE, 415, 309, 450, 364, "", CTRX_LAST);

	ctrx_mouse_click(432, 252, LEFT_BUTTON, 0, "Load document...", CTRX_LAST);

	ctrx_sync_on_window("Open", ACTIVATE, 220, 272, 841, 433, "", CTRX_LAST);

	ctrx_mouse_click(406, 101, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_mouse_click(773, 377, LEFT_BUTTON, 0, "Open", CTRX_LAST);

	ctrx_sync_on_window("Load document...", ACTIVATE, 415, 309, 450, 364, "", CTRX_LAST);

	ctrx_mouse_click(234, 334, LEFT_BUTTON, 0, "Load document...", CTRX_LAST);

	lr_end_transaction("Import_Stl_files",LR_AUTO);

	lr_think_time(53);

	lr_start_transaction("Open_STL_FILES");

	ctrx_sync_on_window("CA Digital - CA Digital", ACTIVATE, 0, 0, 1281, 985, "", CTRX_LAST);

	ctrx_mouse_double_click(263, 282, LEFT_BUTTON, 0, "CA Digital - CA Digital", CTRX_LAST);

	lr_end_transaction("Open_STL_FILES",LR_AUTO);

	lr_think_time(59);

	lr_start_transaction("Step1");

	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, 0, 0, 1281, 985, "", CTRX_LAST);

	ctrx_mouse_click(614, 178, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(14);

	ctrx_mouse_click(646, 189, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_end_transaction("Step1",LR_AUTO);

	lr_think_time(17);

	lr_start_transaction("Step2");

	ctrx_mouse_click(128, 133, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(11);

	ctrx_mouse_click(795, 524, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(956, 524, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(792, 628, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(948, 629, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(6);

	ctrx_mouse_click(142, 467, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(173, 424, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(184, 378, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(199, 348, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(214, 304, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(241, 275, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(274, 261, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(321, 261, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(354, 275, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(382, 314, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(397, 346, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(413, 379, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(427, 419, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(450, 472, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(4);

	ctrx_mouse_click(199, 701, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(4);

	ctrx_mouse_click(215, 757, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(236, 804, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(249, 838, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(265, 870, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(4);

	ctrx_mouse_click(293, 886, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(319, 895, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(345, 889, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(367, 876, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(387, 852, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(416, 829, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(424, 790, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(436, 744, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(453, 689, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(828, 567, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_end_transaction("Step2",LR_AUTO);

	lr_think_time(71);

	lr_start_transaction("Step3");

	ctrx_mouse_click(181, 138, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(127);

	ctrx_mouse_click(763, 187, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(759, 238, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(8);

	ctrx_mouse_click(62, 302, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(17);

	ctrx_mouse_click(393, 327, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(388, 312, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(9);

	ctrx_mouse_down(412, 298, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_up(417, 297, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(8);

	ctrx_mouse_click(353, 284, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_down(372, 294, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_up(375, 294, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(6);

	ctrx_mouse_down(372, 268, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_up(375, 264, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(5);

	ctrx_mouse_click(392, 329, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_down(415, 294, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_up(420, 293, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(390, 317, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_down(410, 296, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_up(416, 295, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(416, 295, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(389, 322, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(10);

	ctrx_mouse_down(369, 328, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(14);

	ctrx_mouse_up(384, 325, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(7);

	ctrx_mouse_down(383, 303, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_up(386, 302, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(6);

	ctrx_mouse_down(381, 328, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(11);

	ctrx_mouse_up(372, 336, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(5);

	ctrx_mouse_click(433, 291, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_end_transaction("Step3",LR_AUTO);

	lr_think_time(19);

	lr_start_transaction("Step4");

	ctrx_mouse_click(247, 130, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_end_transaction("Step4",LR_AUTO);

	lr_think_time(67);

	lr_start_transaction("Export_stl_Files");

	ctrx_mouse_click(51, 921, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(7);

	ctrx_sync_on_window("Save", ACTIVATE, 200, 273, 882, 433, "", CTRX_LAST);

	ctrx_mouse_click(65, 247, LEFT_BUTTON, 0, "Save", CTRX_LAST);

	ctrx_mouse_click(857, 204, LEFT_BUTTON, 0, "Save", CTRX_LAST);

	ctrx_sync_on_window("Select Export File Types", ACTIVATE, 508, 391, 265, 201, "", CTRX_LAST);

	ctrx_mouse_click(20, 52, LEFT_BUTTON, 0, "Select Export File Types", CTRX_LAST);

	ctrx_mouse_click(24, 79, LEFT_BUTTON, 0, "Select Export File Types", CTRX_LAST);

	ctrx_mouse_click(73, 181, LEFT_BUTTON, 0, "Select Export File Types", CTRX_LAST);

	lr_think_time(4);

	ctrx_sync_on_window("Save", ACTIVATE, 200, 273, 882, 433, "", CTRX_LAST);

	ctrx_mouse_click(812, 378, LEFT_BUTTON, 0, "Save", CTRX_LAST);

	web_add_auto_header("Csrf-Token",
		"{CitrixXenApp_CsrfToken}");

	web_add_auto_header("X-Citrix-IsUsingHTTPS", 
		"Yes");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	lr_think_time(159);

	web_custom_request("KeepAlive", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Home/KeepAlive", 
		"Method=HEAD", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Export_stl_Files",LR_AUTO);

	lr_think_time(180);

	lr_start_transaction("Home");

	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, 0, 0, 1281, 985, "", CTRX_LAST);

	ctrx_mouse_double_click(162, 64, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_end_transaction("Home",LR_AUTO);

	lr_think_time(18);

	ctrx_sync_on_window("CA Digital - CA Digital_2", ACTIVATE, 0, 0, 1281, 985, "", CTRX_LAST);

	ctrx_mouse_click(1225, 135, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_down(1220, 128, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_up(1225, 135, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_think_time(12);

	lr_start_transaction("Close_CAD");

	ctrx_mouse_click(1257, 11, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_click(1249, 10, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_double_click(1249, 10, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	ctrx_mouse_up(1249, 10, LEFT_BUTTON, 0, "CA Digital - CA Digital_2", CTRX_LAST);

	lr_end_transaction("Close_CAD",LR_AUTO);

	lr_start_transaction("Close_Citrix");

	ctrx_logoff(CTRX_NORMAL_LOGOFF, CTRX_LAST);

	lr_end_transaction("Close_Citrix",LR_AUTO);

	lr_start_transaction("Logout");

	web_add_cookie("CtxsDesktopAutoLaunchDone=no; DOMAIN=storefront.smileco.com");

	lr_think_time(13);

	web_custom_request("Disconnect", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Sessions/Disconnect", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("Logoff", 
		"URL=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/Authentication/Logoff", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://storefront.smileco.com/Citrix/SmileDirectClubWeb/", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	return 0;
}